
Calgary Directory
Standard Count Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper1.hf
paper1 from      53161 to        34371 in        0.070
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj1.hf
obj1 from        21504 to        17085 in        0.035
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/geo.hf
geo from         102400 to       73592 in        0.154
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progc.hf
progc from       39611 to        26948 in        0.053
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progl.hf
progl from       71646 to        44017 in        0.081
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book1.hf
book1 from       768771 to       439409 in       0.817
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progp.hf
progp from       49379 to        31248 in        0.057
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/pic.hf
pic from         513216 to       107586 in       0.201
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/news.hf
news from        377109 to       247428 in       0.477
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper4.hf
paper4 from      13286 to        8894 in         0.017
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/bib.hf
bib from         111261 to       73795 in        0.133
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper3.hf
paper3 from      46526 to        28309 in        0.052
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper2.hf
paper2 from      82199 to        48649 in        0.087
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper5.hf
paper5 from      11954 to        8465 in         0.015
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj2.hf
obj2 from        246814 to       195131 in       0.349
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/trans.hf
trans from       93695 to        66252 in        0.120
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book2.hf
book2 from       610856 to       369335 in       0.650
--------
total bytes read: 3251493
total compressed bytes 1845571
total percent compression 43.239
compression time: 3.488

Standard Tree Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper6.hf
paper6 from      38105 to        24166 in        0.125
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper1.hf
paper1 from      53161 to        33483 in        0.069
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj1.hf
obj1 from        21504 to        16419 in        0.037
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/geo.hf
geo from         102400 to       72925 in        0.153
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progc.hf
progc from       39611 to        26056 in        0.049
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progl.hf
progl from       71646 to        43117 in        0.078
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book1.hf
book1 from       768771 to       438503 in       0.812
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progp.hf
progp from       49379 to        30352 in        0.056
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/pic.hf
pic from         513216 to       106785 in       0.199
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/news.hf
news from        377109 to       246544 in       0.431
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper4.hf
paper4 from      13286 to        7985 in         0.014
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/bib.hf
bib from         111261 to       72888 in        0.132
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper3.hf
paper3 from      46526 to        27406 in        0.049
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper2.hf
paper2 from      82199 to        47756 in        0.085
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper5.hf
paper5 from      11954 to        7571 in         0.015
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj2.hf
obj2 from        246814 to       194464 in       0.345
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/trans.hf
trans from       93695 to        65369 in        0.116
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book2.hf
book2 from       610856 to       368448 in       0.649
--------
total bytes read: 3251493
total compressed bytes 1830237
total percent compression 43.711
compression time: 3.414

Waterloo Directed

Standard Count Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/sail.tif.hf
sail.tif from    1179784 to      1085501 in      2.047
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/monarch.tif.hf
monarch.tif from         1179784 to      1109973 in      2.032
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/clegg.tif.hf
clegg.tif from   2149096 to      2034595 in      4.555
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/lena.tif.hf
lena.tif from    786568 to       766146 in       1.329
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/serrano.tif.hf
serrano.tif from         1498414 to      1127645 in      2.033
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/peppers.tif.hf
peppers.tif from         786568 to       756968 in       1.368
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/tulips.tif.hf
tulips.tif from  1179784 to      1135861 in      2.059
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/frymire.tif.hf
frymire.tif from         3706306 to      2188593 in      5.018
--------
total bytes read: 12466304
total compressed bytes 10205282
total percent compression 18.137
compression time: 20.441

Standard Tree Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/sail.tif.hf
sail.tif from    1179784 to      1084827 in      2.025
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/monarch.tif.hf
monarch.tif from         1179784 to      1109303 in      2.043
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/clegg.tif.hf
clegg.tif from   2149096 to      2033928 in      4.510
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/lena.tif.hf
lena.tif from    786568 to       765479 in       1.411
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/serrano.tif.hf
serrano.tif from         1498414 to      1126952 in      1.977
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/peppers.tif.hf
peppers.tif from         786568 to       756300 in       1.377
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/tulips.tif.hf
tulips.tif from  1179784 to      1135190 in      2.060
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/waterloo/frymire.tif.hf
frymire.tif from         3706306 to      2187829 in      3.893
--------
total bytes read: 12466304
total compressed bytes 10199808
total percent compression 18.181
compression time: 19.296

BooksAndHTML

Standard Count Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/melville.txt.hf
melville.txt from        82140 to        47364 in        0.165
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/A7_Recursion.html.hf
A7_Recursion.html from   41163 to        26189 in        0.060
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/jnglb10.txt.hf
jnglb10.txt from         292059 to       168618 in       0.325
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/ThroughTheLookingGlass.txt.hf
ThroughTheLookingGlass.txt from  188199 to       110293 in       0.208
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/syllabus.htm.hf
syllabus.htm from        33273 to        21342 in        0.049
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/revDictionary.txt.hf
revDictionary.txt from   1130523 to      611618 in       1.089
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/CiaFactBook2000.txt.hf
CiaFactBook2000.txt from         3497369 to      2260664 in      4.056
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/kjv10.txt.hf
kjv10.txt from   4345020 to      2489768 in      4.496
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/rawMovieGross.txt.hf
rawMovieGross.txt from   117272 to       53833 in        0.102
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/quotes.htm.hf
quotes.htm from  61563 to        38423 in        0.073
--------
total bytes read: 9788581
total compressed bytes 5828112
total percent compression 40.460
compression time: 10.623

Standard Tree Format
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/melville.txt.hf
melville.txt from        82140 to        46436 in        0.168
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/A7_Recursion.html.hf
A7_Recursion.html from   41163 to        25298 in        0.050
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/jnglb10.txt.hf
jnglb10.txt from         292059 to       167720 in       0.303
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/ThroughTheLookingGlass.txt.hf
ThroughTheLookingGlass.txt from  188199 to       109396 in       0.197
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/syllabus.htm.hf
syllabus.htm from        33273 to        20448 in        0.038
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/revDictionary.txt.hf
revDictionary.txt from   1130523 to      610638 in       1.152
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/CiaFactBook2000.txt.hf
CiaFactBook2000.txt from         3497369 to      2259772 in      4.048
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/kjv10.txt.hf
kjv10.txt from   4345020 to      2488872 in      4.531
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/rawMovieGross.txt.hf
rawMovieGross.txt from   117272 to       52831 in        0.096
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/BooksAndHTML/quotes.htm.hf
quotes.htm from  61563 to        37528 in        0.068
--------
total bytes read: 9788581
total compressed bytes 5818939
total percent compression 40.554
compression time: 10.651


Calgary Standard Tree Format Compression for .hf files
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book1.hf.hf.hf
book1.hf.hf from         434362 to       434804 in       0.890
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper3.hf.hf.hf
paper3.hf.hf from        28220 to        28567 in        0.063
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj1.hf.hf
obj1.hf from     16419 to        16578 in        0.032
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/trans.hf.hf
trans.hf from    65369 to        64992 in        0.116
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/pic.hf.hf
pic.hf from      106785 to       71238 in        0.123
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/trans.hf.hf.hf
trans.hf.hf from         64992 to        65365 in        0.118
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper1.hf.hf.hf
paper1.hf.hf from        33620 to        33991 in        0.066
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper5.hf.hf.hf
paper5.hf.hf from        8352 to         8664 in         0.023
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/news.hf.hf.hf
news.hf.hf from  246362 to       246815 in       0.440
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj2.hf.hf.hf
obj2.hf.hf from  193392 to       193809 in       0.342
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/geo.hf.hf.hf
geo.hf.hf from   72845 to        73236 in        0.135
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book1.hf.hf
book1.hf from    438503 to       433243 in       0.752
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper5.hf.hf
paper5.hf from   7571 to         7861 in         0.016
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progc.hf.hf.hf
progc.hf.hf from         26135 to        26503 in        0.054
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book2.hf.hf.hf
book2.hf.hf from         367407 to       367850 in       0.666
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper1.hf.hf
paper1.hf from   33483 to        33620 in        0.062
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper2.hf.hf.hf
paper2.hf.hf from        48373 to        48706 in        0.090
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/bib.hf.hf
bib.hf from      72888 to        72246 in        0.127
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/news.hf.hf
news.hf from     246544 to       245473 in       0.437
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/bib.hf.hf.hf
bib.hf.hf from   72246 to        72625 in        0.133
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper6.hf.hf.hf
paper6.hf.hf from        24376 to        24746 in        0.049
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj1.hf.hf.hf
obj1.hf.hf from  16578 to        16933 in        0.036
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper4.hf.hf
paper4.hf from   7985 to         8257 in         0.016
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper4.hf.hf.hf
paper4.hf.hf from        8257 to         8619 in         0.022
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper3.hf.hf
paper3.hf from   27406 to        27520 in        0.048
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progp.hf.hf.hf
progp.hf.hf from         30186 to        30551 in        0.059
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progl.hf.hf
progl.hf from    43117 to        42678 in        0.077
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progp.hf.hf
progp.hf from    30352 to        30186 in        0.054
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/book2.hf.hf
book2.hf from    368448 to       366385 in       0.639
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper6.hf.hf
paper6.hf from   24166 to        24376 in        0.045
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/pic.hf.hf.hf
pic.hf.hf from   71238 to        70276 in        0.128
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/paper2.hf.hf
paper2.hf from   47756 to        47586 in        0.085
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/geo.hf.hf
geo.hf from      72925 to        72845 in        0.129
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/obj2.hf.hf
obj2.hf from     194464 to       193392 in       0.338
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progc.hf.hf
progc.hf from    26056 to        26135 in        0.046
compressing to: /Users/akaman150/CS314/Assignment 10/HuffmanSource/calgary/progl.hf.hf.hf
progl.hf.hf from         42678 to        43052 in        0.082
--------
total bytes read: 3619856
total compressed bytes 3579723
total percent compression 1.109
compression time: 6.538


Analysis:

Text-based files seemed to have better compression percentages when using the huffman coding algorithm. The Calgary files 
had a total compression of around 43% for both header formats and the BooksAndHTML files had a total compression of around
40%. On the other hand, the file in the Waterloo directory had around 18% compression. These files were images as opposed to 
texts. Therefore, it can be said that our implementation of Huffman coding is more effective with text files over images.

Compressing already compressed files:
We ran the compression algorith over some compressed files and double compressed files to see what would happen. What we saw
that barely any compression occured and in some cases, the file after compression was larger. This means that we can't simply
run the hufmman coding algorithm on the same file agin and again and get smaller and smaller files. This is likely due to the 
fact that the compressed file can have multiple letters or "bits of information" with in the 8 bits that the preprocessor reads.
Therefore it is less likely to find repeating strings of 8 bits to compress to smaller quantities. 

